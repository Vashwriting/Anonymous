﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TravelManagementSystem
{
    /// <summary>
    /// Interaction logic for EmpLogin.xaml
    /// </summary>
    public partial class EmpLogin : Page
    {
        public EmpLogin()
        {
            InitializeComponent();
        }

        private void Btnback_Click(object sender, RoutedEventArgs e)
        {
            NavigationService nav;
            nav = NavigationService.GetNavigationService(this);
            MainWindow nextPage = new MainWindow();
            nav.Navigate(nextPage);
        }

      

        private void EmpReg_click(object sender, RoutedEventArgs e)
        {

             EmpRegPage page = new EmpRegPage();
             
        }
    }
}
