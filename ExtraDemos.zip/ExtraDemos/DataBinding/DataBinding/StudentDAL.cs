﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBinding
{
    class StudentDAL
    {
        List<Student> students = null;

        public StudentDAL()
        {
            students = new List<Student>()
            {
                new Student{ RollNo = 101, Name = "Tushar", FeesPaid = 43000},
                new Student{ RollNo = 102, Name = "Manisha", FeesPaid = 47000},
                new Student{ RollNo = 103, Name = "Umesh", FeesPaid = 39000}
            };
        }

        public List<Student> SelectAll()
        {           
            return students;
        }

        internal void Insert(Student s1)
        {
            students.Add(s1);
        }
    }
}
