﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataBinding
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        StudentDAL dal = new StudentDAL();
        public Window1()
        {
            InitializeComponent();
            //this.DataContext = dal.SelectAll();
        }

        private void LbStudName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Student stud = (Student) lbStudName.SelectedItem;
            MessageBox.Show(stud.RollNo + " | " + stud.Name);
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            Student s1 = new Student { RollNo = 104, Name = "Pravin", FeesPaid = 23233 };
            dal.Insert(s1);
            dgStuds.ItemsSource = dal.SelectAll();
        }   
    }
}
