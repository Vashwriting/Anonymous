﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace codefirst_student_master
{
    class Student_Master:DbContext
    {
        public Student_Master():base("Trainings")
        {

        }
        public DbSet<Student_Master_172467> dbset { get; set; }
    }
}
