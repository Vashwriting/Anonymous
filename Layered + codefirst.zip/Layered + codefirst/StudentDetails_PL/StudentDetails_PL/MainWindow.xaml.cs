﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Student_BAL;
using Student_Entities;
using Student_Exzception;
using Student_DAL;
using System.Data.SqlClient;

namespace StudentDetails_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public void Clear()
        {
            txtStudCode.Text = "";
            txtStudName.Text = "";
            txtDeptCode.Text = "";
            txtDob.Text = "";
            txtAddress.Text = "";
           
        }
        public new void Show()
        {
            try
            {
                List<StudentEntity> studList = StudentBAl.RetrieveStudent();

                if (studList == null || studList.Count <= 0)
                    throw new Student_Exce("Records not available");
                else
                {
                    dgStudent.DataContext = studList;
                }
            }
            catch (Student_Exce ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Show();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                StudentEntity stud = new StudentEntity();

                stud.Scode = Convert.ToInt32(txtStudCode.Text);
                stud.SName = txtStudName.Text;
                stud.DCode = Convert.ToInt32(txtDeptCode.Text);
                stud.Dob = Convert.ToDateTime(txtDob.Text);
                stud.Address = txtAddress.Text;

                int recordsAffected = StudentBAl.InsertStudent(stud);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record inserted successfully");
                    Show();
                    Clear();
                }
                else
                    throw new Student_Exce("Record not inserted");
            }
            catch (Student_Exce ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int studCode = Convert.ToInt32(txtStudCode.Text);

                StudentEntity stud = StudentBAl.SearchStudent(studCode);

                if (stud != null)
                {
                    txtStudCode.Text = stud.Scode.ToString();
                    txtStudName.Text = stud.SName;
                    txtDeptCode.Text = stud.DCode.ToString();
                    txtDob.Text = stud.Dob.ToString();
                    txtAddress.Text = stud.Address;

                    update.IsEnabled = true;
                    del.IsEnabled = true;
                    //txtStudCode.IsReadOnly = true;
                    //txtStudName.IsReadOnly = true;
                    //txtDob.IsEnabled = false;
                }
                else
                    throw new Student_Exce("Student record not found");
            }
            catch (Student_Exce ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                StudentEntity stud = new StudentEntity();

                stud.Scode = Convert.ToInt32(txtStudCode.Text);
                stud.SName = txtStudName.Text;
                stud.DCode = Convert.ToInt32(txtDeptCode.Text);
                stud.Dob = Convert.ToDateTime(txtDob.Text);
                stud.Address = txtAddress.Text;

                int recordsAffected = StudentBAl.UpdateStudent(stud);

                if (recordsAffected >0)
                {
                    MessageBox.Show("Record updated successfully");
                    Show();
                    Clear();
                }
                else
                    throw new Student_Exce("Record not updated");
            }
            catch (Student_Exce ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Del_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int studCode = Convert.ToInt32(txtStudCode.Text);

                int recordsAffected = StudentBAl.DeleteStudent(studCode);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record Deleted Successfully");
                    Show();
                    Clear();
                }
                else
                    throw new Student_Exce("Record not deleted");
            }
            catch (Student_Exce ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
            

        private void Cnt_Click(object sender, RoutedEventArgs e)
        {

            SqlCommand cmd = DataConnection.GenerateCommand();
            cmd.CommandText = "usp_Count_Student";


            cmd.Connection.Open();
            int count = (int)cmd.ExecuteScalar();
            cmd.Connection.Close();
            

            MessageBox.Show("Number of students are: " + count);
        }

        private void Clr_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }
    }
}
                                                                     