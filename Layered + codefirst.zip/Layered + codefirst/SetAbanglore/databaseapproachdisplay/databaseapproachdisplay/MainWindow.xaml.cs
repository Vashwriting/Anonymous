﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace databaseapproachdisplay
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
       
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Training_23Jan19_MumbaiEntities contextObj = new Training_23Jan19_MumbaiEntities();
            CustDetails_172312 newCustomer = new CustDetails_172312();
            //query for displaying employees in India and working in Bangalore and ordering them by Customer ID
            var searchQuery = from cust in contextObj.CustDetails_172312
                              where cust.Country == "India" && cust.City == "mum"
                              orderby cust.CustomerID descending
                              select cust;

            if (searchQuery.Count() > 0)//if employee found display
            {
                dgEmployee.ItemsSource = searchQuery.ToList<CustDetails_172312>();
                MessageBox.Show(string.Format("Customer Found" + "\n" + newCustomer.CustomerName, newCustomer.CustomerID.ToString()), "Customer Information System");
            }
            else//will show no customer found
            {
                MessageBox.Show("Customer Not Found");
            }
        }
    }
}
