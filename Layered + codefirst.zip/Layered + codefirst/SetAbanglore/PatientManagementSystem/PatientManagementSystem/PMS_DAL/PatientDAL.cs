﻿using PMS_Entity1;
using PMS_Exception;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS_DAL
{
    public class PatientDAL
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;



        static PatientDAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public PatientDAL()
        {
            con = new SqlConnection(conStr);

        }

        public void AddPatientDAL(Patient pboj)
        {
            //int pid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand("Ins_Patientdetails_172312", con);

                //cmd.CommandText = "Nepun.udp_insert_patientDetails";
                //cmd.Connection = con;

                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.AddWithValue("@dateLogin", pboj.LoginTime);
                cmd.Parameters.AddWithValue("@firstName", pboj.FistName);
                cmd.Parameters.AddWithValue("@lastName", pboj.LastName);
                cmd.Parameters.AddWithValue("@gender", pboj.Gender);
                cmd.Parameters.AddWithValue("@Address", pboj.Address);
                cmd.Parameters.AddWithValue("@city", pboj.City);
                cmd.Parameters.AddWithValue("@State", pboj.State);
                cmd.Parameters.AddWithValue("@pinCode", pboj.PinCode);
                cmd.Parameters.AddWithValue("@phoneNumber", pboj.PhoneNumber);


                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                //pid = int.Parse(cmd.Parameters["@pId"].Value.ToString());
            }
            catch (PatientException)
            {
                throw;
            }

            catch (SqlException)
            {
                throw;
            }

            //catch (SystemException)
            //{
            //    throw;
            //}

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            //return pid;
        }


        public DataTable DisplayPatientDAL()
        {
            DataTable dt=null;
            try
            {
                cmd = new SqlCommand("Display_Patientdetails_172312", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }

            }

            catch (SqlException)
            {
                throw;

            }

            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            return dt;
        }


    }
}

