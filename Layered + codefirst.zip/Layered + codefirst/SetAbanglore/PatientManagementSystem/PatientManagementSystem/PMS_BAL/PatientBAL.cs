﻿using PMS_DAL;
using PMS_Entity1;
using PMS_Exception;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PMS_BAL
{
    public class PatientBAL
    {
        private bool ValidatePatient(Patient newPatient)
        {
            bool isValidpatient = true;
            StringBuilder sbPMSError = new StringBuilder();


            if (!(Regex.IsMatch(newPatient.FistName, "[A-Z][a-z]{3,}")))
            {
                isValidpatient = false;
                sbPMSError.Append("patient Name must have only characters starting with uppercase " + Environment.NewLine);
            }


            if (!(Regex.IsMatch(newPatient.PhoneNumber.ToString(), "^[6-9][0-9]{9}$")))
            {
                isValidpatient = false;
                sbPMSError.Append("Patient contact should have 10 digits or First digit should be greater than 6" + Environment.NewLine);
            }

            //if (!(Regex.IsMatch(newPatient.PinCode.ToString(), "^{6}$")))

            //{
            //    isValidpatient = false;
            //    sbPMSError.Append("PinCode should have 6 digits" + Environment.NewLine);

            //}

            if (String.IsNullOrEmpty(newPatient.FistName))
            {
                sbPMSError.Append("First Name Required" + Environment.NewLine);
            }

            if (String.IsNullOrEmpty(newPatient.LastName))
            {
                sbPMSError.Append("Last Name Required" + Environment.NewLine);
            }

            if (String.IsNullOrEmpty(newPatient.Address))
            {
                sbPMSError.Append("Address Required" + Environment.NewLine);
            }

            if (String.IsNullOrEmpty(newPatient.City))
            {
                sbPMSError.Append("City Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(newPatient.State))
            {
                sbPMSError.Append("State Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(newPatient.PinCode))
            {
                sbPMSError.Append("Pin code Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(Convert.ToString(newPatient.PhoneNumber)))
            {
                sbPMSError.Append("Phone Number Required" + Environment.NewLine);
            }


            if (!isValidpatient)

            { throw new PatientException(sbPMSError.ToString()); }

            return isValidpatient;
        }




        public void AddPatientBAL(Patient pobj)
        {
            try
            {

                if (ValidatePatient(pobj))
                {
                    PatientDAL pd = new PatientDAL();
                    pd.AddPatientDAL(pobj);
                }
                else
                {
                    throw new PatientException("Failed to Add Patient");
                }

            }

            catch (PatientException)
            {
                throw;
            }

        }


        public DataTable DisplayPatientBAL()
        {
            PatientDAL st = new PatientDAL();


            DataTable dtpatient = st.DisplayPatientDAL();

            try
            {
                if (dtpatient.Rows.Count <= 0)
                {
                    throw new PatientException("No Patient Available");
                }

            }
            catch (PatientException pe)
            {
                throw pe;

            }
            catch (SqlException se)
            {

                throw se;
            }
            return dtpatient;
        }


    }
}
