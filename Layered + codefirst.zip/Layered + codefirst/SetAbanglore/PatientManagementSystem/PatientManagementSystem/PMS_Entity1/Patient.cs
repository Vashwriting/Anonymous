﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS_Entity1
{
    public class Patient
    {
        public int PatientId { get; set; }
        public DateTime LoginTime { get; set; }
        public string FistName { get; set; }
        public string LastName { get; set; }
        public char Gender { get; set; }//string//
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PinCode { get; set; }
        public long PhoneNumber { get; set; }

    }
}
