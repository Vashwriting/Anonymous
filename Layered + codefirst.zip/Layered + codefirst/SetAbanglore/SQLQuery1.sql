/*create Patient Table*/

create table Patientdetails_172312(
patientId int identity(100,1),
dateLogin date,
firstName varchar(20),
lastName varchar(20),
gender char,
Address varchar(70),
city varchar(20),
State varchar(20),
pinCode varchar(6),
phoneNumber bigint)

alter table Patientdetails_172312
add constraint pkpatient primary key (patientId)



select * from  Patientdetails_172312

drop table Patientdetails_172312





create procedure Ins_Patientdetails_172312
(
	
	@DateLogin date,
	@FirstName varchar(30),
	@LastName varchar(30),
	@Gender char(10),
	@Address varchar(50),
	@City varchar(50),
    @State varchar(50),
	@PinCode varchar(50),
	@PhoneNumber bigint
	)
	AS
BEGIN
Insert into Patientdetails_172312(DateLogin,FirstName,LastName,Gender,Address,City,State,PinCode,PhoneNumber) values ( @DateLogin,@FirstName,@LastName,@Gender,@Address,@City,@State,@PinCode,@PhoneNumber);
END



create procedure Display_Patientdetails_172312
 
AS
BEGIN
select * from Patientdetails_172312
END
