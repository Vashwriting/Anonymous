﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Hrishi_BAL;
using Hrishi_Entities;
using Hrishi_Exceptions;


namespace Hrishi
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }



        public void Clear()
        {
            txtempid.Text = "";
            txtempname.Text = "";
            txtdoj.Text = "";
            txtmid.Text = "";
            

        }
        public void Show()
        {
            try
            {
                List<Hrishi1> hrishiList = HrishiBAL.RetrieveEmployee();

                if (hrishiList == null || hrishiList.Count <= 0)
                    throw new HrishiValidationException("Records not available");
                else
                {

                    dgemployee.ItemsSource = hrishiList;
                }
            }
            catch (HrishiValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Hrishi1 emp = new Hrishi1();

                emp.Employee_id= Convert.ToInt32(txtempid.Text);
                emp.Employee_name = txtempname.Text;
                emp.Manager_id = Convert.ToInt32(txtmid.Text);
                emp.Doj = Convert.ToDateTime(txtdoj.Text);
                //stud.Address = txtStudAddress.Text;

                int recordsAffected = HrishiBAL.InsertEmployee(emp);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record inserted successfully");
                    Show();
                    Clear();
                }
                else
                    throw new HrishiValidationException("Record not inserted");
            }
            catch (HrishiValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }

        private void update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Hrishi1 emp = new Hrishi1();

                emp.Employee_id = Convert.ToInt32(txtempid.Text);
                emp.Employee_name = txtempname.Text;
                emp.Manager_id = Convert.ToInt32(txtmid.Text);
                emp.Doj = Convert.ToDateTime(txtdoj.Text);
                //emp.Address = txtStudAddress.Text;

                int recordsAffected = HrishiBAL.UpdateEmployee(emp);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record updated successfully");
                    Show();
                    Clear();
                    
                }
                else
                    throw new HrishiNotFound("Record not updated");
            }
            catch (HrishiValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void count_Click(object sender, RoutedEventArgs e)
        {


            
            MessageBox.Show("Number of Employees are: " + HrishiBAL.CountEmployee());

        }

        private void search_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                int empid = Convert.ToInt32(txtempid.Text);

                Hrishi1 emp = HrishiBAL.SearchEmployee(empid);

                if (emp != null)
                {
                    txtempid.Text = emp.Employee_id.ToString();
                    txtempname.Text = emp.Employee_name;
                    txtdoj.Text = emp.Doj.ToString();
                    txtmid.Text = emp.Manager_id.ToString();

                    btnUpdate.IsEnabled = true;
                    btnDelete.IsEnabled = true;
                    //txtempid.IsReadOnly = true;
                    //txtempname.IsReadOnly = false;
                    //txtdoj.IsEnabled = true;
                    //txtmid.IsEnabled = true;
                }
                else
                    throw new HrishiValidationException("Employee record not found");
            }
            catch (HrishiValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int empid = Convert.ToInt32(txtempid.Text);

                int recordsAffected = HrishiBAL.DeleteEmployee(empid);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record Deleted Successfully");
                    Show();
                    Clear();
                }
                else
                    throw new HrishiNotFound("Record not deleted");
            }
            catch (HrishiValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

    

    private void clear_Click(object sender, RoutedEventArgs e)
        {

            Clear();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Show();
        }
    }
}
