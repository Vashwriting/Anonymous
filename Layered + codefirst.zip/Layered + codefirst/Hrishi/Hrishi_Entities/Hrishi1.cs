﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hrishi_Entities
{
    public class Hrishi1
    {
        public int Employee_id { get; set; }
        public string Employee_name { get; set; }
        public int Manager_id { get; set; }
        public DateTime Doj { get; set; }
        //public int Address { get; set; }
    }
}
