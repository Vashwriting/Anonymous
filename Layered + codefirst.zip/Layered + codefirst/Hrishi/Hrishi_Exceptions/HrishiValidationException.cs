﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hrishi_Exceptions
{
    public class HrishiValidationException : Exception
    {
        public HrishiValidationException(string message)  //constructor is inheritating base class Exception
               : base(message)
        {

        }
    }
}
