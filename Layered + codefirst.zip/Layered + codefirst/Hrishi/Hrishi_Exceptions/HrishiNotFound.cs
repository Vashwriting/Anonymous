﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hrishi_Exceptions
{
    public  class HrishiNotFound : Exception
    {
        public HrishiNotFound(string message)
        : base(message)
        {

        }
    }
}
