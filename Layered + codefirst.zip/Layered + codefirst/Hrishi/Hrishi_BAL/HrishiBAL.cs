﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hrishi_DAL;
using Hrishi_Entities;
using Hrishi_Exceptions;
using System.Text.RegularExpressions;

namespace Hrishi_BAL
{
    public class HrishiBAL
    {
        public static bool ValildateEmployee(Hrishi1 emp)
        {
            bool empValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (emp.Employee_id <= 0)
                {
                    empValidated = false;
                    message.Append("Employee code should be greater than 0\n");
                }

                if (emp.Employee_name == String.Empty)
                {
                    empValidated = false;
                    message.Append("Employee name should be provided\n");
                }
                else if (!Regex.IsMatch(emp.Employee_name, "[A-Z][a-z]+"))
                {
                    empValidated = false;
                    message.Append("Employee name should have alphabets only\n");
                }

                if (emp.Doj == null)
                {
                    empValidated = false;
                    message.Append("Employee Date of Joining should be provided\n");
                }

                if (empValidated == false)
                    throw new HrishiValidationException(message.ToString());
            }
            catch (HrishiValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empValidated;
        }

        public static int InsertEmployee(Hrishi1 emp)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateEmployee(emp))
                {
                    recordsAffected = HrishiDAL.InsertEmployee(emp);
                }
                else
                    throw new HrishiValidationException("Please provide valid Employee Information");
            }
            catch (HrishiValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
        public static List<Hrishi1> RetrieveEmployee()
        {
            List<Hrishi1> hrishiList = null;

            try
            {
                hrishiList = HrishiDAL.RetrieveEmployee();
            }
            catch (HrishiValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return hrishiList;
        }

        public static int UpdateEmployee(Hrishi1 stud)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateEmployee(stud))
                {
                    recordsAffected = HrishiDAL.UpdateEmployee(stud);
                }
                else
                    throw new HrishiValidationException("Please provide valid Employee Information");
            }
            catch (HrishiNotFound ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Hrishi1 SearchEmployee(int Empid)
        {
            Hrishi1 emp = null;

            try
            {
                emp = HrishiDAL.SearchEmployee(Empid);
            }
            catch (HrishiValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;
        }


        public static int DeleteEmployee(int EmpId)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = HrishiDAL.DeleteEmployee(EmpId);
            }
            catch (HrishiValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int CountEmployee()
        {
            int count = 0;

            try
            {
                count = HrishiDAL.CountEmployee();
            }
            catch (HrishiValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return count;
        }
    }
   
}
