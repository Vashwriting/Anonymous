﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hrishi_Entities;
using Hrishi_Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace Hrishi_DAL
    
{
    public class HrishiDAL
    {
        public static int InsertEmployee(Hrishi1 emp)
        {
            int recordsAffected = 0;
            List<Hrishi1> hrishis = new List<Hrishi1>();

            try
            {
                //Creating command object
                SqlCommand cmd = dataconnection.GenerateCommand();
                //Assigning command text
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_insertemployee_172430";
                //Adding parameters to command
                cmd.Parameters.AddWithValue("@eid", emp.Employee_id);
                cmd.Parameters.AddWithValue("@ename", emp.Employee_name);
                cmd.Parameters.AddWithValue("@doj", emp.Doj);
                cmd.Parameters.AddWithValue("@mid", emp.Manager_id);
                //cmd.Parameters.AddWithValue("@Address", stud.Address);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static List<Hrishi1> RetrieveEmployee()
        {
            List<Hrishi1> hrishiList = null;

            try
            {
                SqlCommand cmd = dataconnection.GenerateCommand();
                cmd.CommandText = "usp_Displayemployee_172430";
                //cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    hrishiList = new List<Hrishi1>();
                    while (dr.Read())
                    {
                        Hrishi1 emp = new Hrishi1();

                        emp.Employee_id = (int)dr["Employee_id"];
                        emp.Employee_name = dr["Employee_name"].ToString();
                        emp.Manager_id = (int)dr["Manager_id"];
                        emp.Doj = Convert.ToDateTime(dr["Doj"]);
                        // stud.Address = dr["Student_Address"].ToString();

                        hrishiList.Add(emp);
                    }
                }
                else
                    throw new HrishiNotFound("Hrishi haravla !!!");
                cmd.Connection.Close();
            }
            catch (HrishiValidationException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SqlException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch (SystemException ex2)
            {
                Console.WriteLine(ex2.Message);
            }

            return hrishiList;
        }

        public static int UpdateEmployee(Hrishi1 emp)
        {
            int recordsAffected = 0;
            List<Hrishi1> hrishis = new List<Hrishi1>();

            try
            {
                //Creating command object
                SqlCommand cmd = dataconnection.GenerateCommand();
                //Assigning command text
                cmd.Connection.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_Updateemployee_172430";
                //Adding parameters to command
                cmd.Parameters.AddWithValue("@eid", emp.Employee_id);
                cmd.Parameters.AddWithValue("@ename", emp.Employee_name);
                cmd.Parameters.AddWithValue("@doj", emp.Doj);
                cmd.Parameters.AddWithValue("@mid", emp.Manager_id);
                //cmd.Parameters.AddWithValue("@Address", stud.Address);

                //Executing command

                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex1)
            {
                Console.WriteLine(ex1.Message);
            }

            return recordsAffected;
        }

        //Function to search student record based on Student Code
        public static Hrishi1 SearchEmployee(int Empid)
        {
            Hrishi1 emp = null;

            try
            {
                SqlCommand cmd = dataconnection.GenerateCommand();

                cmd.CommandText = "usp_Searchemployee_172430";
                cmd.Parameters.AddWithValue("@eid", Empid);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    emp = new Hrishi1();
                    dr.Read();
                    emp.Employee_id = (int)dr["Employee_id"];
                    emp.Employee_name = dr["Employee_name"].ToString();
                    emp.Manager_id = (int)dr["Manager_id"];
                    emp.Doj = Convert.ToDateTime(dr["Doj"]);
                    //emp.Address = dr["Student_Address"].ToString();
                }
                else
                {
                    Console.WriteLine("Record not found");
                }
                cmd.Connection.Close();
            }
            catch (HrishiValidationException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SqlException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch (SystemException ex2)
            {
                Console.WriteLine(ex2.Message);
            }

            return emp;
        }

        public static int DeleteEmployee(int EmpId)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = dataconnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_Deleteemployee_172430";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@eid", EmpId);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex1)
            {
                Console.WriteLine(ex1.Message);
            }

            return recordsAffected;

        }
        public static int CountEmployee()
        {
            //int count = 0;
            try
            {
                //Creating command object
                SqlCommand cmd = dataconnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_Countemployee_172430";
                //cmd.Parameters.AddWithValue("@eid", EmpId);
                //Executing command
                cmd.Connection.Open();
              int  count = (int)cmd.ExecuteScalar();
                cmd.Connection.Close();
                return count;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            
            
        }
    }
}
