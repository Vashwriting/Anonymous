﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace kuchtohkrtehai
{
    /// <summary>
    /// Interaction logic for ButtonFunctions.xaml
    /// </summary>
    public partial class ButtonFunctions : Window
    {
        public ButtonFunctions()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void click_search(object sender, RoutedEventArgs e)
        {
            Search_Policy page = new Search_Policy();
            page.Show();
        }

        private void click_view(object sender, RoutedEventArgs e)
        {
            ViewPolicyDetails page = new ViewPolicyDetails();
            page.Show();
        }

        private void click_update(object sender, RoutedEventArgs e)
        {
            UpdatePolicyDetails page = new UpdatePolicyDetails();
            page.Show();
        }

        private void click_upload(object sender, RoutedEventArgs e)
        {
            UploadDocuments page = new UploadDocuments();
            page.Show();
        }

        private void click_view_endorsement(object sender, RoutedEventArgs e)
        {
            ViewEndorsement page = new ViewEndorsement();
            page.Show();
        }
    }
}
