﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace kuchtohkrtehai
{
    /// <summary>
    /// Interaction logic for UserAccountCreation.xaml
    /// </summary>
    public partial class UserAccountCreation : Window
    {
        public UserAccountCreation()
        {
            InitializeComponent();
        }

        private void click_next(object sender, RoutedEventArgs e)
        {
           NewUserRegistration page = new NewUserRegistration();
            page.Show();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
