﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace CDapproach
{
    class EmployeeContext_172445 : DbContext
    {
        public DbSet<EmployeeNew_172445> EmployeesNew_172445 { get; set; }
    }
}
