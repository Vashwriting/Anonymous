﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CDapproach
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
                EmployeeContext_172445 context = new EmployeeContext_172445();

            if (context.EmployeesNew_172445 == null)
            {

                context.EmployeesNew_172445.Add(new EmployeeNew_172445() { empID = 1001, FName = "Jaya", LName = "Gudla", Title = "Analyst", Dob = Convert.ToDateTime("3/02/2011"), Doj = Convert.ToDateTime("02/04/2013"), City = "mumbai" });
                context.EmployeesNew_172445.Add(new EmployeeNew_172445() { empID = 1002, FName = "Sumit", LName = "Daruvalla", Title = "Associate", Dob = Convert.ToDateTime("3/02/2011"), Doj = Convert.ToDateTime("02/04/2013"), City = "Pune" });
                context.EmployeesNew_172445.Add(new EmployeeNew_172445() { empID = 1003, FName = "Malcolm", LName = "Dalla", Title = "Consultant", Dob = Convert.ToDateTime("3/02/2011"), Doj = Convert.ToDateTime("02/04/2013"), City = "mumbai" });
                context.EmployeesNew_172445.Add(new EmployeeNew_172445() { empID = 1004, FName = "Madhavi", LName = "Oza", Title = "AsstManager", Dob = Convert.ToDateTime("3/02/2011"), Doj = Convert.ToDateTime("02/04/2013"), City = "mumbai" });
                context.EmployeesNew_172445.Add(new EmployeeNew_172445() { empID = 1005, FName = "Saba", LName = "Shaikh", Title = "Associate", Dob = Convert.ToDateTime("3/02/2011"), Doj = Convert.ToDateTime("02/04/2013"), City = "Pune" });
                context.EmployeesNew_172445.Add(new EmployeeNew_172445() { empID = 1006, FName = "Nazia", LName = "Shaikh", Title = "Consultant", Dob = Convert.ToDateTime("3/02/2011"), Doj = Convert.ToDateTime("02/04/2013"), City = "chennai" });
                context.EmployeesNew_172445.Add(new EmployeeNew_172445() { empID = 1007, FName = "Amit", LName = "Pathak", Title = "AsstManager", Dob = Convert.ToDateTime("3/02/2011"), Doj = Convert.ToDateTime("02/04/2013"), City = "chennai" });
                context.EmployeesNew_172445.Add(new EmployeeNew_172445() { empID = 1008, FName = "Vijay", LName = "Natrajan", Title = "Associate", Dob = Convert.ToDateTime("3/02/2011"), Doj = Convert.ToDateTime("02/04/2013"), City = "Pune" });
                context.EmployeesNew_172445.Add(new EmployeeNew_172445() { empID = 1009, FName = "Rahul", LName = "Gudla", Title = "Analyst", Dob = Convert.ToDateTime("3/02/2011"), Doj = Convert.ToDateTime("02/04/2013"), City = "mumbai" });
                context.EmployeesNew_172445.Add(new EmployeeNew_172445() { empID = 1010, FName = "Suresh", LName = "Shah", Title = "Associate", Dob = Convert.ToDateTime("3/02/2011"), Doj = Convert.ToDateTime("02/04/2013"), City = "Pune" });
            }
            context.SaveChanges();

            dgEmployee.ItemsSource = context.EmployeesNew_172445.ToList();


            //var query = from ins in context.EmployeesNew_172445
            //            where ins.City.Equals("Pune")
            //            select ins;
            //dgEmployee.ItemsSource = query.ToList();

            //Display details of all the employee whose location is not Pune

            //var query2 = context.EmployeesNew_172445.Where(ins => ins.City != "Pune");
            //dgEmployee.ItemsSource = query2.ToList();

            //Display details of all the employee whose title is AsstManager

            //var query3 = from ins in context.EmployeesNew_172445
            //             where ins.Title == "AsstManager"
            //             select ins;
            //dgEmployee.ItemsSource = query3.ToList();


            //Display details of all the employee whose Last Name start with S

            //var query4 = from ins in context.EmployeesNew_172445
            //             where ins.LName.StartsWith("S")
            //             select ins;
            //dgEmployee.ItemsSource = query4.ToList();

            //Display a list of all the employee whose designation is Consultant and Associate


            //var query5 = from ins in context.EmployeesNew_172445
            //             where ins.Title == "Consultant" || ins.Title == "Associate"
            //             select ins;
            //dgEmployee.ItemsSource = query5.ToList();

            //Display a list of all the employee whose date of birth is after 1 / 1 / 1990

            //var query6 = context.EmployeesNew_172445.Where(ins => ins.Dob >= Convert.ToDateTime("1/1/1990"));
            //dgEmployee.ItemsSource = query6.ToList();

            //Display total number of employees

            //int results = context.EmployeesNew_172445.Count();

            //Display total number of employees belonging to “Chennai"

            int results1 = context.EmployeesNew_172445.Count(ins => ins.City == "Chennai");

            //Display highest employee id from the list

            //var query7 = (from c in context.EmployeesNew_172445
            //              where c.empID != 0
            //              select c).Max(c => c.empID);
            //dgEmployee.ItemsSource = query7.ToList();

            //Display total number of employee whose designation is not “Associate”
            //var query11 = context.EmployeesNew_172445.Where(ins => ins.Doj >= Convert.ToDateTime("1/1/2015")).Count();
        }

    }
}
