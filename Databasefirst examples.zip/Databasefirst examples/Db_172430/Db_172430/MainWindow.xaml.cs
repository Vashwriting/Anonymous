﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Db_172430
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_23Jan19_PuneEntities trainingContext = null;
        public MainWindow()
        {
            InitializeComponent();
            trainingContext = new Training_23Jan19_PuneEntities();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            List<hrishi_172430> products = trainingContext.hrishi_172430.ToList();
            var res = from p in products
                      where p.ID.Equals(int.Parse(txt_ID.Text))
                      select p;                         // Binding DridView
            DataGrid1.ItemsSource = res;
            hrishi_172430 stud = trainingContext.hrishi_172430.Find(Convert.ToInt32(txt_ID.Text));    // Search

            if (stud != null)
            {
                DataGrid1.ItemsSource = res;
                var result = MessageBox.Show("Do you want to delete: ", "Delete", MessageBoxButton.YesNoCancel);
                if (result == MessageBoxResult.Yes)
                {

                    trainingContext.hrishi_172430.Remove(stud);
                    int recordsAffected = trainingContext.SaveChanges();
                    if (recordsAffected > 0)
                    {
                        MessageBox.Show("Student Records Deleted Successfully");
                        DataGrid1.ItemsSource = null;
                    }
                    else
                    {
                        MessageBox.Show("Student Records Not Deleted");
                    }
                }
            }
            else
            {
                MessageBox.Show("ID not Found...");
            }

        }
    }
}
