﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;

namespace Database_crud
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static Student_Master_172467 entity = new Student_Master_172467();
        Training_Entities context = new Training_Entities();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try { showdata(); }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //context.dbset.Add(new Student_Master_172467 {  Stud_Name = "sai kumar", Dept_Code = 10,  Doj = DateTime.Now ,address="sikkolu"});
            //context.SaveChanges();
            // // dgStudent1.ItemsSource = context.dbset.ToList();

            //var data = from p in context.dbset select p;

            //dgStudent1.ItemsSource = data.ToList();

        }



        private void Button_Click_Add(object sender, RoutedEventArgs e)
        {
            try
            {
                entity.Stud_Code = int.Parse(tscode.Text);
                entity.Stud_Name = tsname.Text;
                entity.Dept_Code = int.Parse(tdcode.Text);
                entity.Doj = Convert.ToDateTime(tdoj.Text);
                entity.address = taddress.Text;

                context.Student_Master_172467.Add(entity);
                showdata();
                Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void Button_Click_Search(object sender, RoutedEventArgs e)
        {
            try
            {

                int id = Convert.ToInt32(tscode.Text);


                entity = (from p in context.Student_Master_172467
                          where p.Stud_Code == id
                          select p).FirstOrDefault();
                tscode.Text = Convert.ToString(entity.Stud_Code);
                tsname.Text = entity.Stud_Name;
                tdcode.Text = Convert.ToString(entity.Dept_Code);
                tdoj.Text = Convert.ToString(entity.Doj);
                taddress.Text = entity.address;
                update.IsEnabled = true; delete.IsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Button_Click_Update(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(tscode.Text);
                entity = (from p in context.Student_Master_172467
                          where p.Stud_Code == id
                          select p).FirstOrDefault();

                entity.Stud_Name = tsname.Text;
                entity.Dept_Code = int.Parse(tdcode.Text);
                entity.Doj = Convert.ToDateTime(tdoj.Text);
                entity.address = taddress.Text;

                showdata(); Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }






        private void Button_Click_Delete(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(tscode.Text);
                entity = (from p in context.Student_Master_172467
                          where p.Stud_Code == id
                          select p).FirstOrDefault();
                context.Student_Master_172467.Remove(entity);
                showdata(); Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Button_Click_Count(object sender, RoutedEventArgs e)
        {
            try
            {
                var count = (from j in context.Student_Master_172467 select j).Count();
                MessageBox.Show("count is: " + count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click_Clear(object sender, RoutedEventArgs e)
        {
            Clear();
        }
        public void showdata()
        {
            try
            {
                context.SaveChanges();
                var data = from p in context.Student_Master_172467 select p;
                dgStudent1.ItemsSource = data.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void Clear()
        {
            tscode.Text = null;
            tsname.Text = null;
            tdcode.Text = null;
            tdoj.Text = null;
            taddress.Text = null;
            update.IsEnabled = false;
            delete.IsEnabled = false;
        }

        private void Button_Click_search_DeptCode(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(tdcode.Text);
                var k = from j in context.Student_Master_172467
                        where j.Dept_Code == id
                        select j;
                dgStudent1.ItemsSource = k.ToList(); Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
