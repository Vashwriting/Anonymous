﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_Entities;
using EMS_Exceptions;

namespace EMS_DAL
{
    //DAL for Employee CRUD operatrions
    public class EmployeeDAL
    {
        List<Employee> employees = new List<Employee>();
        //Inserting employee into collection
        public void Insert(Employee employee)
        {
            try
            {
                employees.Add(employee);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public void Update(Employee employee)
        {
            try
            {
                for (int i = 0; i < employees.Count; i++)
                {
                    if (employees[i].EmpId == employee.EmpId)
                    {
                        employees[i].EmpName = employee.EmpName;
                        employees[i].Salary = employee.Salary;
                        employees[i].DOJ = employee.DOJ;
                        break;
                    }

                }
            }
            catch(Exception ex)
            {
                throw ex;

            }

        }

        public void Delete(int empId)
        {
            bool isDeleted = false;
            try
            {
                for (int i = 0; i < employees.Count; i++)
                {
                    if (employees[i].EmpId == empId)
                    {
                        //employees.Remove(employees[i]);
                        employees.RemoveAt(i);
                        isDeleted = true;
                        break;
                    }

                }
                if(!isDeleted)
                {
                    throw new EmployeeNotFoundException("Employee Not Found");
                }
            }
            catch(Exception ex)
            {
                throw ex; 
            }

        }

        public List<Employee> SelectAll()
        {

            return employees;
        }


    }
}
