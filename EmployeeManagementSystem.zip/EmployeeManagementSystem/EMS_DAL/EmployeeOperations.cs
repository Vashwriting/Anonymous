﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMP_Entities;
using EMS_Exception;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace EMS_DAL
{
    public class EmployeeOperations
    {

        public static int InsertEmployee(Employee Emp)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_InsertEmployee_172466";
                //Adding parameters to command
                cmd.Parameters.AddWithValue("@eid",Emp.EmpID);
                cmd.Parameters.AddWithValue("@ename", Emp.EmpName);
                cmd.Parameters.AddWithValue("@edob", Emp.DOB);
                cmd.Parameters.AddWithValue("@eemail", Emp.EmailId);                         
                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Function to delete student record from database
        public static int DeleteEmployee(int empid)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeleteEmployee_172466";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@eid", empid);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Function to search employee record based on employee ID
        public static Employee SearchEmployee(int empid)
        {
            Employee emp = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "uso_SearchEmployee_172466";
                cmd.Parameters.AddWithValue("@eid", empid);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    emp = new Employee();
                    dr.Read();
                    emp.EmpID = (int)dr["Employee_Id"];
                    emp.EmpName = dr["Employee_Name"].ToString();
                    emp.DOB = Convert.ToDateTime(dr["Employee_DOB"]);
                    emp.EmailId = dr["Employee_EmailID"].ToString();

                }

                else
                {
                    throw new EmployeeValidationException("Record not found");
                }
                cmd.Connection.Close();
            }
            catch (EmployeeValidationException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;
        }


        //Function to update student record from database
        public static int UpdateEmployee(Employee emp)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_UpdateEmployee_172466";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@eid", emp.EmpID);
                cmd.Parameters.AddWithValue("@edob", emp.DOB);
                cmd.Parameters.AddWithValue("@eemail", emp.EmailId);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }


        //Function to Count Employee record from database
        public static int CountEmployee()
        {
          //  int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Countemployee_172466";

                ////Adding parameters to command
                //cmd.Parameters.AddWithValue("@eid", emp.EmpID);
                //cmd.Parameters.AddWithValue("@edob", emp.DOB);
                //cmd.Parameters.AddWithValue("@eemail", emp.EmailId);

                ////Executing command
                cmd.Connection.Open();
                int count = (int)cmd.ExecuteScalar();

                cmd.Connection.Close();
                return count;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            //return count;
           // return recordsAffected;
        }


        //Function to retrieve all employee record
        public static List<Employee> RetrieveEmployee()
        {
            List<Employee> EmpList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
               cmd.CommandText = "usp_DisplayEmployee_172466";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
               // DataTable dt = new DataTable();
               // dt.Load(dr);

                if (dr.HasRows)
                {
                    EmpList = new List<Employee>();
                    while (dr.Read())
                    {
                        Employee emp = new Employee();

                        emp.EmpID = (int)dr["Employee_Id"];
                        emp.EmpName = dr["Employee_Name"].ToString();
                       
                        emp.DOB = Convert.ToDateTime(dr["Employee_DOB"]);
                        emp.EmailId = dr["Employee_EmailID"].ToString();
                        

                        EmpList.Add(emp);
                    }
                }
                else
                    throw new EmployeeValidationException("Record not available");
                cmd.Connection.Close();
            }
            catch (EmployeeValidationException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return EmpList;
        }

    }
}
