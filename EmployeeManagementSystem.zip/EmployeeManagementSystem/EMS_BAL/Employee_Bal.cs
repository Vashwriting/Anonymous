﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMP_Entities;
using EMS_DAL;
using EMS_Exception;
using System.Text.RegularExpressions;


namespace EMS_BAL
{
    public class Employee_Bal
    {

        public static bool ValildateEmployee(Employee emp)
        {
            bool empValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (emp.EmpID <= 0)
                {
                    empValidated = false;
                    message.Append("Employee ID should be greater than 0\n");
                }

                if (emp.EmpName == String.Empty)
                {
                    empValidated = false;
                    message.Append("Employee name should be provided\n");
                }
                else if (!Regex.IsMatch(emp.EmpName, "[A-Z][a-z]+"))
                {
                    empValidated = false;
                    message.Append("Employee name should have alphabets only\n");

                }


                if (emp.DOB == null)
                {
                    empValidated = false;
                    message.Append("Employee Date of Birth should be provided\n");
                }


                if (!Regex.IsMatch(emp.EmailId, @"^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$"))
                {
                    empValidated = false;
                    message.Append("This is invalid email address" + Environment.NewLine);
                }



                if (empValidated == false)
                    throw new EmployeeValidationException(message.ToString());
            }
            catch (EmployeeValidationException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex1)
            {
                Console.WriteLine(ex1.Message);
            }

            return empValidated;
        }

        public static int InsertBal(Employee emp)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateEmployee(emp))
                {
                    recordsAffected = EmployeeOperations.InsertEmployee(emp);
                }
                else
                    throw new EmployeeValidationException("Please provide valid Employee Information");
            }
            catch (EmployeeValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }




        public static Employee SearchBal(int empid)
        {
            Employee emp = null;

            try
            {
                emp = EmployeeOperations.SearchEmployee(empid);
            }
            catch (EmployeeValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;
        }




        public static int Updatebal(Employee emp)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateEmployee(emp))
                {
                    recordsAffected = EmployeeOperations.UpdateEmployee(emp);
                }
                else
                    throw new EmployeeValidationException("Please provide valid Employee Information");
            }
            catch (EmployeeValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }



        public static int Deletebal(int empid)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = EmployeeOperations.DeleteEmployee(empid);
            }
            catch (EmployeeValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }




        public static int CountBal()
        {
            int count = 0;

            try
            {
                count = EmployeeOperations.CountEmployee();
                
            }
            catch (EmployeeValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return count;
        }




        public static List<Employee> RetrieveEmployee()
        {
            List<Employee> EmpList = null;

            try
            {
                EmpList = EmployeeOperations.RetrieveEmployee();
            }
            catch (EmployeeValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return EmpList;
        }


    }
}
