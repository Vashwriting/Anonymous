﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_Entities;
using EMS_Exceptions;
using EMS_BAL;

namespace EmployeeManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {


            }
            catch (EmployeeValidationException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch (EmployeeNotFoundException ex2)
            {
                Console.WriteLine(ex2.Message);
            }
            catch (Exception ex3)
            {
                throw ex3;
            }
            Console.ReadKey();
        }
    }
}



                //static void DisplayEmployees(List<Employee> employee)
                //{

                //}
                //static void Main(string[] args)
                //{
                //    try
                //    {
                //        /////////////////////////////////////////////////////
                //        EmployeeBAL employeeBAL = new EmployeeBAL();
                //        Employee employee = new Employee
                //        {
                //            EmpId = 1022,
                //            DOJ = DateTime.Now.AddDays(-2),
                //            Salary = 120000,
                //            EmpName = "Rohan"
                //        };
                //        employeeBAL.Add(employee);
                //        Console.WriteLine("Inserted ");

                //        DisplayEmployees(employeeBAL.GetAll());
                //        List<Employee> employees = employeeBAL.GetAll();
                //        foreach(var item in employees)
                //        {
                //            Console.WriteLine(item);    //EMS>Entities.Employee
                //        }


                //        ///////////////////////////////////////////////////////////////////


                //        employee.DOJ = DateTime.Now.AddDays(-2);
                //        employee.Salary = 120000;
                //        employee.EmpName = "Swammy";

                //        employeeBAL.Modify(employee);
                //        Console.WriteLine("Updated ");

                //        foreach (var item in employees)
                //        {
                //            Console.WriteLine(item);    //EMS>Entities.Employee
                //        }

                //        employeeBAL.Remove(1022);
                //        Console.WriteLine("Deleted ");







//            }
//            catch (EmployeeValidationException ex1)
//            {
//                Console.WriteLine(ex1.Message);
//            }
//            catch (EmployeeNotFoundException ex2)
//            {
//                Console.WriteLine(ex2.Message);
//            }
//            catch (Exception ex3)
//            {
//                throw ex3;
//            }
//            Console.ReadKey();
//        }
//    }
//}
