﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using EMP_Entities;
using EMS_Exception;
using EMS_BAL;


namespace EmployeeManagementSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>-
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }




        public void Show()
        {
            try
            {
                List<Employee> EmpList = Employee_Bal.RetrieveEmployee();

                if (EmpList == null || EmpList.Count <= 0)
                    throw new EmployeeValidationException("Records not available");
                else
                {
                    //IEnumerable<Employee> prods = Employee_Bal.RetrieveEmployee();
                  
                    //cmbempName.ItemsSource = EmpList;
                    //cmbempName.DisplayMemberPath = "EmpName";
                    dgemployee.ItemsSource = EmpList;
                }
            }
            catch (EmployeeValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }





        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                Employee emp  = new Employee();

                emp.EmpID = Convert.ToInt32(txtEmpid.Text);
                emp.EmpName = txtEmpName.Text;
                emp.DOB = Convert.ToDateTime(txtEmpDob.Text);
                emp.EmailId = txtEmpemail.Text;
              
                int recordsAffected =  Employee_Bal.InsertBal(emp);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record inserted successfully");
                    Show();
                    clear();
                }
                else
                    throw new EmployeeValidationException("Record not inserted");
            }
            catch (EmployeeValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Show();
        }

        public void clear()
        {
            txtEmpid.Text = "";
            txtEmpName.Text = "";
            txtEmpDob.Text = "";
            txtEmpemail.Text = "";
           
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            clear();
        }




        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int empid = Convert.ToInt32(txtEmpid.Text);

                Employee emp = Employee_Bal.SearchBal(empid);

                if (emp != null)
                {
                    txtEmpid.Text = emp.EmpID.ToString();
                    txtEmpName.Text = emp.EmpName;
                    txtEmpDob.Text = emp.DOB.ToString();
                    txtEmpemail.Text = emp.EmailId;

                    btnUpdate.IsEnabled = true;
                    btnDelete.IsEnabled = true;
                    //txtEmpid.IsReadOnly = true;
                    //txtEmpName.IsReadOnly = true;
                    //txtEmpDob.IsEnabled = true;
                }
                else
                    throw new EmployeeValidationException("Employee record not found");
            }
            catch (EmployeeValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Employee emp = new Employee();

                emp.EmpID = Convert.ToInt32(txtEmpid.Text);
               
               
                emp.DOB = Convert.ToDateTime(txtEmpDob.Text);
                emp.EmailId = txtEmpemail.Text;

                int recordsAffected = Employee_Bal.Updatebal(emp);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record updated successfully");
                    Show();
                    clear();
                }
                else
                    throw new EmployeeValidationException("Record not updated");
            }
            catch (EmployeeValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                int empid = Convert.ToInt32(txtEmpid.Text);

                int recordsAffected = Employee_Bal.Deletebal(empid);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record Deleted Successfully");
                    Show();
                    clear();
                }
                else
                    throw new EmployeeValidationException("Record not deleted");
            }
            catch (EmployeeValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        //private void cmbempName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{

        //    Employee emp = (Employee) cmbempName.SelectedItem;
        //    MessageBox.Show(emp.EmpID.ToString());

        //}

        private void BtnCount_Click(object sender, RoutedEventArgs e)
        {
            

            MessageBox.Show("Number of students are:" + Employee_Bal.CountBal());
        }
    }
}
